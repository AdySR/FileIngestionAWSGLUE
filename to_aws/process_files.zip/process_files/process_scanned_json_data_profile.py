def process_scanned_json_data_profile(source_file_full_path_list):
    print(source_file_full_path_list)