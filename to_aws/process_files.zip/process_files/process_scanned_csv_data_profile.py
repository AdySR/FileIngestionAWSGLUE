def process_scanned_csv_data_profile(source_file_full_path_list):
    print(source_file_full_path_list)